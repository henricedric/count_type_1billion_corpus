import matplotlib.pyplot as plt

f = open(r"C:\Users\floga\Desktop\count.txt")

temps = []
types = []

count = 0
for i in f:
    count = count + 1
    if count % 6 == 3:
        temps.append(int(i))
    elif count % 6 == 4:
        types.append(int(i))
    else: continue


tranches = [n for n in range(1,100)]

plt.subplot(2,1,1)
plt.plot(tranches, temps, color='red')
plt.xlabel('nombre de tranches')
plt.ylabel('temps (min)')
plt.title('temps mis pour compter les occurences')

plt.subplot(2,1,2)
plt.plot(tranches, types, color='green')
plt.xlabel('nombre de tranches')
plt.ylabel('types')
plt.title('types comptés par nombre de tranches')

plt.show()

